# Git Bootcamp example project

This is an example project to demonstrate usage of `git`.

